"""
A Python CLI for Atlas-Checks tools
"""

__version__ = '1.0'
